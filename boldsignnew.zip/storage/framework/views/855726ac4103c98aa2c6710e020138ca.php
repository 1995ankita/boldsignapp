<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document List</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container col-md-8 mt-5">
        <h1>Document Activity List</h1>

        <table class="table table-bordered mt-3">
            <thead class="thead-dark">
                <tr>
                    <th>Document ID</th>
                    <th>Sender</th>
                    <th>Created Date/Sent for Sign</th>
                    <th>Activity Date</th>
                    <th>Activity By</th>
                    <th>Title</th>
                    <th>Status</th>
                    <th>Download</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $response->result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($document->documentId); ?></td>
                        <td><?php echo e($document->senderDetail->name); ?></td>
                        <td><?php echo e(date('Y-m-d H:i:s', $document->createdDate)); ?></td>
                        <td><?php echo e(date('Y-m-d H:i:s', $document->activityDate)); ?></td>
                        <td><?php echo e($document->activityBy); ?></td>
                        <td><?php echo e($document->messageTitle); ?></td>
                        <td><?php echo e($document->status); ?></td>

                        <td>
                            <form method="GET" action="<?php echo e(url('download-pdf')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="documentId" value="<?php echo e($document->documentId); ?>">
                                <button type="submit" class="btn btn-primary">PDF</button>
                            </form>

                            <?php if($document->status == 'Completed'): ?>
                                <form method="GET" action="<?php echo e(url('download-audittrail')); ?>" style="margin-top: 10px;">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="documentId" value="<?php echo e($document->documentId); ?>">
                                    <button type="submit" class="btn btn-primary" style="white-space: nowrap;">Audit-trail</button>
                                </form>
                            <?php endif; ?>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Include Bootstrap JS and Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\boldsignnew\resources\views/list.blade.php ENDPATH**/ ?>